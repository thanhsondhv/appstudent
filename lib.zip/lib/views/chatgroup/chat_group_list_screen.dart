import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'chat_room_screen.dart';

class ChatGroupListScreen extends StatelessWidget {
  const ChatGroupListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final String? myId = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Chat Điều Hành VinhUni", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0054A6), // Màu xanh thương hiệu
        elevation: 0,
      ),
      body: StreamBuilder<QuerySnapshot>(
        // Lấy các nhóm mà mình là thành viên
        stream: FirebaseFirestore.instance
            .collection('groups')
            .where('members', arrayContains: myId)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text("Lỗi kết nối Firebase"));
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final groups = snapshot.data?.docs ?? [];

          if (groups.isEmpty) {
            return _buildEmptyState();
          }

          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: groups.length,
            separatorBuilder: (context, index) => const Divider(height: 1),
            itemBuilder: (context, index) {
              var groupData = groups[index].data() as Map<String, dynamic>;
              String groupId = groups[index].id;
              
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.blue.shade50,
                  child: const Icon(Icons.groups_rounded, color: Color(0xFF0054A6)),
                ),
                title: Text(groupData['group_name'] ?? 'Nhóm thảo luận', 
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: const Text("Nhấn để xem tin nhắn mới nhất"),
                trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChatRoomScreen(
                        groupId: groupId,
                        groupName: groupData['group_name'] ?? 'Nhóm',
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.chat_bubble_outline, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text("Bạn chưa có nhóm chat nào.", style: TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }
}