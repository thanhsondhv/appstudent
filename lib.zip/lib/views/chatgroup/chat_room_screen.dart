import 'package:flutter/material.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:firebase_auth/firebase_auth.dart';

class ChatRoomScreen extends StatefulWidget {
  final String groupId;
  final String groupName;

  const ChatRoomScreen({super.key, required this.groupId, required this.groupName});

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final TextEditingController _msgController = TextEditingController();
  final String? myId = FirebaseAuth.instance.currentUser?.uid;

  void _send() {
    if (_msgController.text.trim().isEmpty) return;
    
    FirebaseFirestore.instance
        .collection('groups')
        .doc(widget.groupId)
        .collection('messages')
        .add({
      'text': _msgController.text.trim(),
      'senderId': myId,
      'timestamp': FieldValue.serverTimestamp(),
      'senderName': 'Cán bộ/SV', // Chỗ này Sơn có thể lấy từ Profile lưu ở máy
    });
    
    _msgController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.groupName, style: const TextStyle(fontSize: 18)),
        backgroundColor: const Color(0xFF0054A6),
        actions: [
          IconButton(
            icon: const Icon(Icons.auto_awesome, color: Colors.amber),
            onPressed: () {
              // TODO: Mở Dialog AI tóm tắt văn bản từ Zalo
              debugPrint("Mở AI Zalo Helper cho nhóm ${widget.groupId}");
            },
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _buildMessageList()),
          _buildInputArea(),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('groups')
          .doc(widget.groupId)
          .collection('messages')
          .orderBy('timestamp', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const SizedBox();
        final docs = snapshot.data!.docs;
        
        return ListView.builder(
          reverse: true,
          padding: const EdgeInsets.all(10),
          itemCount: docs.length,
          itemBuilder: (context, index) {
            var msg = docs[index].data() as Map<String, dynamic>;
            bool isMe = msg['senderId'] == myId;
            return _chatBubble(msg['text'], isMe);
          },
        );
      },
    );
  }

  Widget _chatBubble(String text, bool isMe) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: isMe ? const Color(0xFF0054A6) : Colors.grey[200],
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(15),
            topRight: const Radius.circular(15),
            bottomLeft: Radius.circular(isMe ? 15 : 0),
            bottomRight: Radius.circular(isMe ? 0 : 15),
          ),
        ),
        child: Text(text, style: TextStyle(color: isMe ? Colors.white : Colors.black87)),
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)]),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _msgController,
              decoration: const InputDecoration(hintText: "Nhập tin nhắn...", border: InputBorder.none),
            ),
          ),
          IconButton(icon: const Icon(Icons.send, color: Color(0xFF0054A6)), onPressed: _send),
        ],
      ),
    );
  }
}