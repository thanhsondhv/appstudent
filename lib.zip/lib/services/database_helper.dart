import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;
  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    // 🔥 Đổi sang v4 để cập nhật thêm cột UserCode và TabGroup
    _database = await _initDB('vinhuni_notifs_v4.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE notifications (
        id INTEGER PRIMARY KEY,
        UserCode TEXT,        -- 🔥 Mã SV/CB để lọc tin riêng
        TieuDe TEXT,
        TomTat TEXT,
        NoiDung TEXT,
        NgayPhatHanh TEXT,
        IsRead INTEGER DEFAULT 0,
        NguoiDang TEXT,
        LoaiTin TEXT,
        TabGroup TEXT,       -- 🔥 Để chia 4 Tab
        is_deleted_local INTEGER DEFAULT 0 
      )
    ''');
    // 2. 🔥 BẢNG LƯU BỘ LỌC (Năm học, Học kỳ)
    await db.execute('''
      CREATE TABLE exam_filters (
        StudentId TEXT PRIMARY KEY,
        RawJson TEXT -- Lưu cả cụm JSON cho nhanh
      )
    ''');

    // 3. 🔥 BẢNG LƯU LỊCH THI CHI TIẾT
    await db.execute('''
      CREATE TABLE exams (
        KeyId TEXT PRIMARY KEY, -- Cấu trúc: studentId_year_semester
        ExamJson TEXT,
        LastUpdated TEXT
      )
    ''');
    // 🔥 BẢNG MỚI 1: LƯU BỘ LỌC LỊCH HỌC (Năm/Kỳ/Tuần)
    await db.execute('''
      CREATE TABLE schedule_filters (
        StudentId TEXT PRIMARY KEY,
        RawJson TEXT
      )
    ''');

    // 🔥 BẢNG MỚI 2: LƯU LỊCH HỌC CHI TIẾT
    await db.execute('''
      CREATE TABLE schedules (
        KeyId TEXT PRIMARY KEY, -- Cấu trúc: sid_year_sem_week_prog
        ScheduleJson TEXT,
        LastUpdated TEXT
      )
    ''');
    await db.execute('''
    CREATE TABLE student_stats (
      StudentId TEXT PRIMARY KEY,
      StatsJson TEXT
    )
  ''');
  // 1. Thêm bảng vào hàm _createDB (Nếu chưa có)
  await db.execute('CREATE TABLE IF NOT EXISTS grade_filters (StudentId TEXT PRIMARY KEY, FilterJson TEXT)');
  await db.execute('CREATE TABLE IF NOT EXISTS grades (KeyId TEXT PRIMARY KEY, GradeJson TEXT)');
  }
    // 2. Thêm các hàm xử lý
  Future<void> saveGradeFilters(String sid, List data) async {
    final db = await instance.database;
    await db.insert('grade_filters', {'StudentId': sid, 'FilterJson': jsonEncode(data)}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List?> getGradeFilters(String sid) async {
    final db = await instance.database;
    final res = await db.query('grade_filters', where: 'StudentId = ?', whereArgs: [sid]);
    if (res.isNotEmpty) return jsonDecode(res.first['FilterJson'] as String);
    return null;
  }

  Future<void> saveGrades(String sid, String y, String s, String p, List data) async {
    final db = await instance.database;
    String key = "${sid}_${y}_${s}_$p";
    await db.insert('grades', {'KeyId': key, 'GradeJson': jsonEncode(data)}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List?> getGrades(String sid, String y, String s, String p) async {
    final db = await instance.database;
    String key = "${sid}_${y}_${s}_$p";
    final res = await db.query('grades', where: 'KeyId = ?', whereArgs: [key]);
    if (res.isNotEmpty) return jsonDecode(res.first['GradeJson'] as String);
    return null;
  }
  Future<void> saveStudentStats(String sid, List data) async {
    final db = await instance.database;
    await db.insert('student_stats', {
      'StudentId': sid,
      'StatsJson': jsonEncode(data)
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List?> getStudentStats(String sid) async {
    final db = await instance.database;
    final res = await db.query('student_stats', where: 'StudentId = ?', whereArgs: [sid]);
    if (res.isNotEmpty) return jsonDecode(res.first['StatsJson'] as String);
    return null;
  }
  Future<void> saveScheduleFilters(String sid, List data) async {
    final db = await instance.database;
    await db.insert('schedule_filters', {'StudentId': sid, 'RawJson': jsonEncode(data)}, 
      conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List?> getScheduleFilters(String sid) async {
    final db = await instance.database;
    final res = await db.query('schedule_filters', where: 'StudentId = ?', whereArgs: [sid]);
    if (res.isNotEmpty) return jsonDecode(res.first['RawJson'] as String);
    return null;
  }

  Future<void> saveSchedule(String sid, String y, String s, String w, String p, List data) async {
    final db = await instance.database;
    String key = "${sid}_${y}_${s}_${w}_$p";
    await db.insert('schedules', {
      'KeyId': key,
      'ScheduleJson': jsonEncode(data),
      'LastUpdated': DateTime.now().toIso8601String()
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List?> getSchedule(String sid, String y, String s, String w, String p) async {
    final db = await instance.database;
    String key = "${sid}_${y}_${s}_${w}_$p";
    final res = await db.query('schedules', where: 'KeyId = ?', whereArgs: [key]);
    if (res.isNotEmpty) return jsonDecode(res.first['ScheduleJson'] as String);
    return null;
  }
  Future<void> saveExamFilters(String studentId, List data) async {
    final db = await instance.database;
    await db.insert('exam_filters', {'StudentId': studentId, 'RawJson': jsonEncode(data)}, 
      conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List?> getExamFilters(String studentId) async {
    final db = await instance.database;
    final res = await db.query('exam_filters', where: 'StudentId = ?', whereArgs: [studentId]);
    if (res.isNotEmpty) return jsonDecode(res.first['RawJson'] as String);
    return null;
  }

  // Lưu/Lấy danh sách Lịch thi
  Future<void> saveExams(String studentId, String year, String semester, List data) async {
    final db = await instance.database;
    String key = "${studentId}_${year}_$semester";
    await db.insert('exams', {
      'KeyId': key,
      'ExamJson': jsonEncode(data),
      'LastUpdated': DateTime.now().toIso8601String()
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List?> getExams(String studentId, String year, String semester) async {
    final db = await instance.database;
    String key = "${studentId}_${year}_$semester";
    final res = await db.query('exams', where: 'KeyId = ?', whereArgs: [key]);
    if (res.isNotEmpty) return jsonDecode(res.first['ExamJson'] as String);
    return null;
  }

  // Lấy tin offline theo UserCode
  Future<List<Map<String, dynamic>>> getOfflineNotifs(String userCode) async {
    final db = await instance.database;
    final cleanId = userCode.toUpperCase().replaceFirst(RegExp(r'^(SV|CB)'), '');

    final res = await db.query(
      'notifications', 
      where: 'is_deleted_local = 0 AND UserCode = ?', 
      whereArgs: [cleanId],
      orderBy: 'id DESC'
    );
    
    return res.map((n) => {
      'ID': n['id'],
      'TieuDe': n['TieuDe'],
      'TomTat': n['TomTat'],
      'NoiDung': n['NoiDung'],
      'NgayPhatHanh': n['NgayPhatHanh'],
      'IsRead': n['IsRead'] == 1,
      'NguoiDang': n['NguoiDang'],
      'LoaiTin': n['LoaiTin'],
      'TabGroup': n['TabGroup'],
    }).toList();
  }

  Future<void> insertNotification(Map<String, dynamic> n, String userCode) async {
    final db = await instance.database;
    final cleanId = userCode.toUpperCase().replaceFirst(RegExp(r'^(SV|CB)'), '');

    await db.insert(
      'notifications',
      {
        'id': n['ID'],
        'UserCode': cleanId,
        'TieuDe': n['TieuDe'] ?? '',
        'TomTat': n['TomTat'] ?? '',
        'NoiDung': n['NoiDung'] ?? '',
        'NgayPhatHanh': n['NgayPhatHanh'] ?? '',
        'IsRead': (n['IsRead'] == true || n['IsRead'] == 1) ? 1 : 0,
        'NguoiDang': n['NguoiDang'] ?? 'Hệ thống',
        'LoaiTin': n['LoaiTin'] ?? 'GENERAL',
        'TabGroup': n['TabGroup'] ?? 'GENERAL',
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deletePermanently(int id, String studentId) async {
    final db = await instance.database;
    await db.update('notifications', {'is_deleted_local': 1}, where: 'id = ?', whereArgs: [id]);
    try {
      await http.post(
        Uri.parse("https://mobi.vinhuni.edu.vn/api/hide-notif/$id"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"student_id": studentId}),
      ).timeout(const Duration(seconds: 5));
    } catch (e) { debugPrint("⚠️ Lỗi xóa tin: $e"); }
  }
}