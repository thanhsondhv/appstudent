import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_auth/firebase_auth.dart'; // 🔥 THÊM DÒNG NÀY
import 'package:flutter_secure_storage/flutter_secure_storage.dart'; 
import '../services/notification_service.dart';
import 'dart:io'; // Để check Platform

class LoginHandler {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static Future<bool> isFaceRegistered(String numericId, String loginUserName) async {
    try {
      String? savedUser = await _storage.read(key: 'bio_user');
      return (savedUser == loginUserName || savedUser == numericId);
    } catch (e) {
      return false;
    }
  }

  static Future<void> executeSuccessfulLogin(
      BuildContext context, 
      String userId, 
      String fullName, 
      {String? role, String? firebaseChatToken} // 🔥 THÊM THAM SỐ firebaseChatToken
  ) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      String cleanId = userId.replaceAll(RegExp(r'[^0-9]'), '');
      if (cleanId.isEmpty) cleanId = userId;

      // 1. Lưu thông tin vào bộ nhớ đệm
      await prefs.setString('user_id', cleanId);
      await prefs.setString('user_code', cleanId);
      await prefs.setString('full_name', fullName);
      await prefs.setString('user_role', role ?? 'CanBo');
      await prefs.setBool('is_logged_in', true);

      // 2. 🔥 ĐĂNG NHẬP FIREBASE CHAT (NGẦM)
      if (firebaseChatToken != null && firebaseChatToken.isNotEmpty) {
        try {
          await FirebaseAuth.instance.signInWithCustomToken(firebaseChatToken);
          debugPrint("✅ [Firebase] Đã đăng nhập hệ thống Chat thành công.");
        } catch (e) {
          debugPrint("⚠️ [Firebase] Lỗi Auth Chat: $e");
          // Không return ở đây để user vẫn vào được app nếu chat lỗi
        }
      }

      // 3. Đồng bộ Notify & Subscribe Topic (Bọc try-catch để tránh lỗi máy ảo iOS)
      try {
        NotificationService.syncTokenToServer(cleanId);
        
        // Chỉ subscribe topic nếu không phải máy ảo iOS (tránh lỗi đỏ lòm Sơn gặp nãy)
        if (!Platform.isIOS || (Platform.isIOS && !const bool.fromEnvironment('dart.vm.product'))) {
             await FirebaseMessaging.instance.subscribeToTopic("vinhuni_all_students");
        }
      } catch (e) {
        debugPrint("⚠️ [FCM] Bỏ qua subscribe trên môi trường này: $e");
      }

      debugPrint("✅ [Handler] Đã hoàn tất luồng login cho $role: $cleanId");

      await Future.delayed(const Duration(milliseconds: 200));

      if (context.mounted) {
        Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
      }
    } catch (e) {
      debugPrint("❌ Lỗi nghiêm trọng tại LoginHandler: $e");
    }
  }
}