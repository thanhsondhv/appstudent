import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationHistoryScreen extends StatefulWidget {
  const NotificationHistoryScreen({super.key});
  @override
  State<NotificationHistoryScreen> createState() => _NotificationHistoryScreenState();
}

class _NotificationHistoryScreenState extends State<NotificationHistoryScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<dynamic> _historyList = [], _filteredList = [];
  bool _isLoading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString('user_code') ?? "";
    try {
      final res = await http.get(Uri.parse("https://mobi.vinhuni.edu.vn/api/lecturer/sent-history/$id"));
      if (res.statusCode == 200) {
        setState(() { _historyList = jsonDecode(res.body)['data'] ?? []; _filteredList = _historyList; _isLoading = false; });
      }
    } catch (e) { if (mounted) setState(() => _isLoading = false); }
  }

  void _filter(String q) {
    setState(() => _filteredList = _historyList.where((i) => i['title'].toString().toLowerCase().contains(q.toLowerCase())).toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1F5F9),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0054A6),
        title: const Text("LỊCH SỬ GỬI TIN", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold)),
        bottom: TabBar(
          controller: _tabController, labelColor: Colors.white, unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.orange, indicatorWeight: 3,
          tabs: const [Tab(text: "Tất cả"), Tab(text: "Lớp/Nhóm"), Tab(text: "Khoa/Viện")],
        ),
      ),
      body: Column(
        children: [
          Padding(padding: const EdgeInsets.all(12), child: TextField(controller: _searchController, onChanged: _filter, decoration: InputDecoration(hintText: "Tìm kiếm...", prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)))),
          Expanded(
            child: _isLoading ? const Center(child: CircularProgressIndicator()) : TabBarView(
              controller: _tabController,
              children: [ _buildList(0), _buildList(1), _buildList(2) ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList(int tab) {
    var list = _filteredList;
    if (tab == 1) list = _filteredList.where((e) => ["LHP", "LOP_HC", "LHP_LOW"].contains(e['scope'])).toList();
    if (tab == 2) list = _filteredList.where((e) => ["DEPT_COHORT"].contains(e['scope'])).toList();

    return ListView.builder(
      padding: const EdgeInsets.all(10),
      itemCount: list.length,
      itemBuilder: (ctx, idx) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: ListTile(
          title: Text(list[idx]['title'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          subtitle: Text(list[idx]['time'], style: const TextStyle(fontSize: 11)),
          trailing: _buildBadge(list[idx]['read'] ?? 0, list[idx]['total'] ?? 0),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => ThongKeChiTietScreen(queueId: list[idx]['id'], title: list[idx]['title']))),
        ),
      ),
    );
  }

  Widget _buildBadge(int read, int total) {
    double p = total > 0 ? (read / total) : 0;
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text("${(p * 100).toInt()}%", style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.green)),
      Text("$read/$total", style: const TextStyle(fontSize: 9, color: Colors.grey)),
    ]);
  }
}

class ThongKeChiTietScreen extends StatefulWidget {
  final int queueId; final String title;
  const ThongKeChiTietScreen({super.key, required this.queueId, required this.title});
  @override
  State<ThongKeChiTietScreen> createState() => _ThongKeChiTietScreenState();
}

class _ThongKeChiTietScreenState extends State<ThongKeChiTietScreen> {
  List<dynamic> _list = []; bool _loading = true;
  @override
  void initState() { super.initState(); _fetch(); }
  Future<void> _fetch() async {
    try {
      final res = await http.get(Uri.parse("https://mobi.vinhuni.edu.vn/api/lecturer/notification-report/${widget.queueId}"));
      if (res.statusCode == 200) setState(() { _list = jsonDecode(res.body)['data'] ?? []; _loading = false; });
    } catch (e) { setState(() => _loading = false); }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF0054A6), title: Text(widget.title, style: const TextStyle(fontSize: 13, color: Colors.white))),
      body: _loading ? const Center(child: CircularProgressIndicator()) : ListView.separated(
        itemCount: _list.length, separatorBuilder: (c, i) => const Divider(height: 1),
        itemBuilder: (c, i) => ListTile(title: Text(_list[i]['name'] ?? "N/A"), subtitle: Text(_list[i]['sid'] ?? ""), trailing: Icon(_list[i]['is_read'] ? Icons.check_circle : Icons.radio_button_unchecked, color: _list[i]['is_read'] ? Colors.green : Colors.grey, size: 16)),
      ),
    );
  }
}