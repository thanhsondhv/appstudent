import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

// =========================================================
// 1. MÀN HÌNH DASHBOARD LỊCH SỬ (PRO VERSION)
// =========================================================
class NotificationHistoryScreen extends StatefulWidget {
  const NotificationHistoryScreen({super.key});

  @override
  State<NotificationHistoryScreen> createState() => _NotificationHistoryScreenState();
}

class _NotificationHistoryScreenState extends State<NotificationHistoryScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _senderId = "";
  bool _isLoading = true;
  List<dynamic> _historyList = [];
  List<dynamic> _filteredList = [];
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    _senderId = prefs.getString('user_code') ?? "";
    if (_senderId.isEmpty) return;

    try {
      final res = await http.get(Uri.parse("https://mobi.vinhuni.edu.vn/api/lecturer/sent-history/$_senderId"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            _historyList = data['data'] ?? [];
            _filteredList = _historyList;
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _filterSearch(String query) {
    setState(() {
      _filteredList = _historyList.where((item) {
        final title = (item['title'] ?? "").toLowerCase();
        final content = (item['content'] ?? "").toLowerCase();
        return title.contains(query.toLowerCase()) || content.contains(query.toLowerCase());
      }).toList();
    });
  }

  List<dynamic> _getDataByTab(int tabIndex) {
    if (tabIndex == 0) return _filteredList; 
    if (tabIndex == 1) return _filteredList.where((e) => ["LHP", "LOP_HC", "LHP_LOW", "INDIVIDUAL"].contains(e['scope'])).toList();
    return _filteredList.where((e) => ["ALL", "KHOA"].contains(e['scope'])).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1F5F9),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0054A6),
        elevation: 0,
        title: const Text("QUẢN TRỊ THÔNG BÁO", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
        centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20), onPressed: () => Navigator.pop(context)),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.orange, // Màu thanh gạch chân dưới Tab
          indicatorWeight: 3,
          
          // 🔥 CHỈNH MÀU CHỮ TẠI ĐÂY
          labelColor: Colors.white,           // Màu chữ khi đang được chọn
          unselectedLabelColor: Colors.white70, // Màu chữ khi không được chọn (hơi mờ cho Pro)
          
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
          tabs: const [
            Tab(text: "Tất cả"),
            Tab(text: "Lớp/Nhóm"),
            Tab(text: "Hệ thống"),
          ],
        ),
      ),
      body: Column(
        children: [
          _buildSearchBar(),
          Expanded(
            child: _isLoading 
              ? const Center(child: CircularProgressIndicator())
              : TabBarView(
                  controller: _tabController,
                  children: List.generate(3, (index) => _buildListContent(index)),
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: const EdgeInsets.all(15),
      color: const Color(0xFF0054A6),
      child: TextField(
        controller: _searchController,
        onChanged: _filterSearch,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: "Tìm kiếm tiêu đề, nội dung...",
          hintStyle: const TextStyle(color: Colors.white70, fontSize: 13),
          prefixIcon: const Icon(Icons.search, color: Colors.white70),
          filled: true,
          fillColor: Colors.white.withOpacity(0.1),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(vertical: 0),
        ),
      ),
    );
  }

  Widget _buildListContent(int tabIndex) {
    final list = _getDataByTab(tabIndex);
    if (list.isEmpty) return _buildEmptyState();

    return RefreshIndicator(
      onRefresh: _loadHistory,
      child: ListView.builder(
        padding: const EdgeInsets.all(15),
        itemCount: list.length,
        itemBuilder: (ctx, idx) {
          final item = list[idx];
          final style = _getScopeStyle(item['scope']);

          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: InkWell(
              borderRadius: BorderRadius.circular(15),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => ThongKeChiTietScreen(queueId: item['id'], title: item['title'] ?? "Thống kê"))),
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: style['bg'], borderRadius: BorderRadius.circular(12)),
                      child: Icon(style['icon'], color: style['color'], size: 24),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item['title'] ?? "Không tiêu đề", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                          const SizedBox(height: 5),
                          Row(
                            children: [
                              _buildBadge(style['label'], style['color']),
                              const SizedBox(width: 8),
                              Text(item['time'], style: const TextStyle(fontSize: 10, color: Colors.grey)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    _buildReadStats(item['read'] ?? 0, item['total'] ?? 0),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildBadge(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(5)),
      child: Text(label, style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: color)),
    );
  }

  Widget _buildReadStats(int read, int total) {
    double percent = total > 0 ? (read / total) : 0;
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(width: 35, height: 35, child: CircularProgressIndicator(value: percent, strokeWidth: 3, backgroundColor: Colors.grey[200], valueColor: AlwaysStoppedAnimation<Color>(percent > 0.6 ? Colors.green : Colors.orange))),
            Text("${(percent * 100).toInt()}%", style: const TextStyle(fontSize: 8, fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 4),
        Text("$read/$total", style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
      ],
    );
  }

  Map<String, dynamic> _getScopeStyle(String? scope) {
    switch (scope?.toUpperCase()) {
      case 'INDIVIDUAL': return {'label': 'Cá nhân', 'icon': Icons.person, 'color': Colors.orange, 'bg': Colors.orange.shade50};
      case 'LHP': return {'label': 'Lớp HP', 'icon': Icons.class_, 'color': Colors.blue, 'bg': Colors.blue.shade50};
      case 'LOP_HC': return {'label': 'Lớp HC', 'icon': Icons.assignment_ind, 'color': Colors.teal, 'bg': Colors.teal.shade50};
      case 'LHP_LOW': return {'label': 'Lớp ít SV', 'icon': Icons.warning_amber, 'color': Colors.red, 'bg': Colors.red.shade50};
      case 'ALL': return {'label': 'Toàn trường', 'icon': Icons.public, 'color': Colors.purple, 'bg': Colors.purple.shade50};
      case 'KHOA': return {'label': 'Theo khóa', 'icon': Icons.school, 'color': Colors.indigo, 'bg': Colors.indigo.shade50};
      default: return {'label': 'Khác', 'icon': Icons.mail, 'color': Colors.grey, 'bg': Colors.grey.shade50};
    }
  }

  Widget _buildEmptyState() => const Center(child: Text("Không có dữ liệu thông báo", style: TextStyle(color: Colors.grey)));
}

// =========================================================
// 2. MÀN HÌNH CHI TIẾT THỐNG KÊ (SỬA LỖI UNDEFINED)
// =========================================================
class ThongKeChiTietScreen extends StatefulWidget {
  final int queueId;
  final String title;
  const ThongKeChiTietScreen({super.key, required this.queueId, required this.title});

  @override
  State<ThongKeChiTietScreen> createState() => _ThongKeChiTietScreenState();
}

class _ThongKeChiTietScreenState extends State<ThongKeChiTietScreen> {
  List<dynamic> _list = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetchReport();
  }

  Future<void> _fetchReport() async {
    try {
      final res = await http.get(Uri.parse("https://mobi.vinhuni.edu.vn/api/lecturer/notification-report/${widget.queueId}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) setState(() { _list = data['data'] ?? []; _loading = false; });
      }
    } catch (e) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    int readCount = _list.where((e) => e['is_read'] == true).length;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0054A6),
        title: Text(widget.title, style: const TextStyle(fontSize: 14, color: Colors.white)),
        leading: IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Navigator.pop(context)),
      ),
      body: _loading 
        ? const Center(child: CircularProgressIndicator())
        : Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 20),
                color: Colors.blue.shade50,
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _statCol("Tổng", _list.length, Colors.blue),
                  _statCol("Đã đọc", readCount, Colors.green),
                  _statCol("Chưa xem", _list.length - readCount, Colors.red),
                ]),
              ),
              Expanded(
                child: ListView.separated(
                  itemCount: _list.length,
                  separatorBuilder: (ctx, idx) => const Divider(height: 1),
                  itemBuilder: (ctx, idx) {
                    final item = _list[idx];
                    return ListTile(
                      leading: Icon(item['is_read'] ? Icons.check_circle : Icons.radio_button_unchecked, color: item['is_read'] ? Colors.green : Colors.grey),
                      title: Text(item['name'] ?? "N/A", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text(item['sid'] ?? "N/A", style: const TextStyle(fontSize: 11)),
                      trailing: Text(item['is_read'] ? (item['time'] ?? "") : "Chưa xem", style: const TextStyle(fontSize: 10, color: Colors.blueGrey)),
                    );
                  },
                ),
              ),
            ],
          ),
    );
  }

  Widget _statCol(String l, int v, Color c) => Column(children: [Text(v.toString(), style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: c)), Text(l, style: const TextStyle(fontSize: 11))]);
}