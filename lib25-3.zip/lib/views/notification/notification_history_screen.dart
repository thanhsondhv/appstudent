import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'notification_helper.dart';

class SendGroupScreen extends StatefulWidget {
  final String? initialScope; 
  const SendGroupScreen({super.key, this.initialScope});

  @override
  State<SendGroupScreen> createState() => _SendGroupScreenState();
}

class _SendGroupScreenState extends State<SendGroupScreen> {
  // --- CONTROLLERS ---
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  final _thresholdController = TextEditingController(text: "20");
  final _imageUrlController = TextEditingController(); // Thêm ô nhập link ảnh

  // --- TRẠNG THÁI ---
  String _selectedScope = "LHP";
  String _selectedCategory = "GENERAL";
  String _senderId = "";
  String _userRole = "canbo"; 
  bool _isLoading = false, _isClassLoading = false, _isSearching = false;

  // --- DATA BỘ LỌC ---
  List<dynamic> _filters = [];
  List<String> _years = [], _semesters = [];
  String? _selectedYear, _selectedSemester, _selectedClass;
  List<dynamic> _classList = [];

  // --- DATA LỚP HÀNH CHÍNH & KHÓA (KHOA) ---
  List<dynamic> _adminClassFullList = [];
  List<String> _adminCourses = [];
  String? _selectedAdminCourse, _selectedAdminClassId;
  List<dynamic> _filteredAdminClasses = [];

  // 🔥 DANH SÁCH KHÓA CỨNG (61-67)
  final List<String> _cohorts = ["61", "62", "63", "64", "65", "66", "67"];
  String? _selectedCohort;

  // --- DATA LHP ÍT SV ---
  List<dynamic> _lowEnrollmentClasses = [];
  List<dynamic> _allLowStudents = []; 
  Set<String> _selectedMultiClassIds = {}; 

  final List<Map<String, String>> _categories = [
    {'id': 'GENERAL', 'name': 'Thông báo chung'},
    {'id': 'CANH_BAO', 'name': 'Cảnh báo học tập'},
    {'id': 'LHP_MSG', 'name': 'Thông báo giải tán/Dồn lớp'},
    {'id': 'LICH_DAY', 'name': 'Lịch dạy / Lịch thi'},
  ];

  @override
  void initState() {
    super.initState();
    _initData();
  }

  Future<void> _initData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() { 
      _senderId = prefs.getString('user_code') ?? ""; 
      _userRole = (prefs.getString('user_role') ?? "canbo").toLowerCase();
      if (widget.initialScope != null) _selectedScope = widget.initialScope!;
    });
    _loadAllFilters();
    if (_selectedScope == "LOP_HC") _fetchAdminClasses();
  }

  List<String> _getAvailableScopes() {
    if (_userRole == 'admin' || _userRole == 'ad') {
      return ["LHP", "LOP_HC", "LHP_LOW", "KHOA", "ALL"];
    } else if (_userRole == 'covan') {
      return ["LHP", "LOP_HC", "LHP_LOW"];
    } else {
      return ["LHP"];
    }
  }

  // --- API LOGIC ---

  Future<void> _loadAllFilters() async {
    try {
      final res = await http.get(Uri.parse("https://mobi.vinhuni.edu.vn/api/get-filters/$_senderId"));
      if (res.statusCode == 200) {
        final List<dynamic> data = jsonDecode(res.body);
        setState(() {
          _filters = data;
          _years = data.map((e) => e['nam'].toString()).toSet().toList()..sort((a, b) => b.compareTo(a));
        });
      }
    } catch (e) {}
  }

  Future<void> _fetchClasses() async {
    if (_selectedYear == null || _selectedSemester == null) return;
    setState(() => _isClassLoading = true);
    final url = "https://mobi.vinhuni.edu.vn/api/lecturer/classes-filtered?lecturer_id=$_senderId&nam=$_selectedYear&ky=${Uri.encodeComponent(_selectedSemester!)}";
    try {
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);
      if (data['status'] == 'success') setState(() { _classList = data['data']; _selectedClass = null; });
    } finally { setState(() => _isClassLoading = false); }
  }

  Future<void> _fetchAdminClasses() async {
    setState(() => _isClassLoading = true);
    try {
      final res = await http.get(Uri.parse("https://mobi.vinhuni.edu.vn/api/lecturer/admin-classes/$_senderId"));
      if (res.statusCode == 200) {
        final result = jsonDecode(res.body);
        setState(() {
          _adminClassFullList = result['data'];
          _adminCourses = _adminClassFullList.map((e) => e['khoa'].toString()).toSet().toList()..sort((a, b) => b.compareTo(a));
        });
      }
    } finally { setState(() => _isClassLoading = false); }
  }

  Future<void> _searchLowEnrollmentData() async {
    if (_selectedYear == null || _selectedSemester == null) {
      NotificationHelper.showSnack(context, "Vui lòng chọn Năm và Kỳ học!", Colors.orange);
      return;
    }
    setState(() => _isSearching = true);
    final queryParams = "nam=$_selectedYear&ky=${Uri.encodeComponent(_selectedSemester!)}&threshold=${_thresholdController.text}";
    try {
      final resClasses = await http.get(Uri.parse("https://mobi.vinhuni.edu.vn/api/admin/low-enrollment-theory-classes?$queryParams"));
      final resStudents = await http.get(Uri.parse("https://mobi.vinhuni.edu.vn/api/admin/low-enrollment-students?$queryParams"));

      if (resClasses.statusCode == 200 && resStudents.statusCode == 200) {
        setState(() {
          _lowEnrollmentClasses = jsonDecode(resClasses.body)['data'] ?? [];
          _allLowStudents = jsonDecode(resStudents.body)['data'] ?? [];
          _selectedMultiClassIds.clear();
        });
      }
    } finally { setState(() => _isSearching = false); }
  }

  // --- XỬ LÝ GỬI TIN ---
  Future<void> _handleSend() async {
    if (_titleController.text.trim().isEmpty || _contentController.text.trim().isEmpty) {
      NotificationHelper.showSnack(context, "Vui lòng nhập nội dung!", Colors.orange); return;
    }

    String finalTargetId = "";
    String apiUrl = 'https://mobi.vinhuni.edu.vn/api/admin/send-notification';

    if (_selectedScope == "LHP") {
      finalTargetId = _selectedClass ?? "";
      apiUrl = 'https://mobi.vinhuni.edu.vn/api/admin/send-notification-lhp';
    } else if (_selectedScope == "LOP_HC") {
      finalTargetId = _selectedAdminClassId ?? "";
      apiUrl = 'https://mobi.vinhuni.edu.vn/api/admin/send-notification-lophc';
    } else if (_selectedScope == "LHP_LOW") {
      finalTargetId = _selectedMultiClassIds.join(","); 
      apiUrl = 'https://mobi.vinhuni.edu.vn/api/admin/send-notification-multi-lhp-theory';
    } else if (_selectedScope == "KHOA") {
      // 🔥 Gửi mã khóa dạng K62, K63...
      finalTargetId = _selectedCohort != null ? "K$_selectedCohort" : "";
    } else if (_selectedScope == "ALL") {
      finalTargetId = "ALL";
    }

    if (finalTargetId.isEmpty && _selectedScope != "ALL") {
      NotificationHelper.showSnack(context, "Vui lòng chọn đối tượng!", Colors.red); return;
    }

    setState(() => _isLoading = true);
    try {
      final body = {
        "sender_id": _senderId, 
        "scope": _selectedScope, 
        "target_id": finalTargetId,
        "category": _selectedCategory, 
        "title": _titleController.text.trim(), 
        "content": _contentController.text.trim(),
        "image_url": _imageUrlController.text.trim(), // Gửi thêm link ảnh
      };
      final res = await http.post(Uri.parse(apiUrl), headers: {'Content-Type': 'application/json'}, body: jsonEncode(body));
      if (res.statusCode == 200) {
        NotificationHelper.showSnack(context, "Gửi thành công!", Colors.green);
        Navigator.pop(context);
      }
    } catch (e) { NotificationHelper.showSnack(context, "Lỗi Server", Colors.red); }
    finally { setState(() => _isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("GỬI TIN TẬP THỂ", style: TextStyle(fontSize: 15, color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0054A6),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios, color: Colors.white), onPressed: () => Navigator.pop(context)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            NotificationHelper.buildLabel("Phạm vi gửi tin"),
            NotificationHelper.buildDropdown(
              hint: "Chọn phạm vi", items: _getAvailableScopes(), value: _selectedScope,
              onChanged: (v) { 
                setState(() { _selectedScope = v!; _lowEnrollmentClasses.clear(); }); 
                if (v == "LOP_HC" && _adminClassFullList.isEmpty) _fetchAdminClasses();
              },
              displayFunc: (id) => {
                'LHP': 'Lớp học phần (Giảng dạy)', 
                'LOP_HC': 'Lớp hành chính (Cố vấn)', 
                'LHP_LOW': 'Lớp lý thuyết ít SV',
                'KHOA': 'Theo khóa học (K61-K67)', 
                'ALL': 'Toàn trường'
              }[id]!,
            ),
            const SizedBox(height: 20),

            // --- UI CHO TỪNG SCOPE ---
            if (_selectedScope == "LHP") ...[
              Row(children: [
                Expanded(child: NotificationHelper.buildDropdown(hint: "Năm học", items: _years, value: _selectedYear, onChanged: (v) {
                  setState(() { _selectedYear = v; _semesters = _filters.where((e) => e['nam'].toString() == v).map((e) => e['ky'].toString()).toSet().toList(); });
                })),
                const SizedBox(width: 10),
                Expanded(child: NotificationHelper.buildDropdown(hint: "Học kỳ", items: _semesters, value: _selectedSemester, onChanged: (v) {
                  setState(() => _selectedSemester = v); _fetchClasses();
                })),
              ]),
              const SizedBox(height: 12),
              if (_isClassLoading) const LinearProgressIndicator()
              else NotificationHelper.buildDropdown(hint: "Chọn lớp HP", items: _classList.map((e) => e['ma_lop'].toString()).toList(), value: _selectedClass, onChanged: (v) => setState(() => _selectedClass = v), displayFunc: (id) => _classList.firstWhere((e) => e['ma_lop'] == id)['ten_lop']),
            ],

            if (_selectedScope == "LOP_HC") ...[
              NotificationHelper.buildDropdown(hint: "Chọn khóa", items: _adminCourses, value: _selectedAdminCourse, onChanged: (v) {
                setState(() { _selectedAdminCourse = v; _filteredAdminClasses = _adminClassFullList.where((e) => e['khoa'] == v).toList(); _selectedAdminClassId = null; });
              }),
              const SizedBox(height: 12),
              NotificationHelper.buildDropdown(hint: "Chọn lớp hành chính", items: _filteredAdminClasses.map((e) => e['id'].toString()).toList(), value: _selectedAdminClassId, onChanged: (v) => setState(() => _selectedAdminClassId = v), displayFunc: (id) => _filteredAdminClasses.firstWhere((e) => e['id'].toString() == id)['ten']),
            ],

            // 🔥 UI CHO KHÓA HỌC (DÙNG COMBOBOX K61-K67)
            if (_selectedScope == "KHOA") ...[
              NotificationHelper.buildLabel("Chọn khóa sinh viên nhận tin"),
              NotificationHelper.buildDropdown(
                hint: "Chọn khóa (K)", 
                items: _cohorts, 
                value: _selectedCohort, 
                onChanged: (v) => setState(() => _selectedCohort = v),
                displayFunc: (id) => "Khóa $id (K$id)",
              ),
            ],

            // 🔥 UI CHO TOÀN TRƯỜNG (CẢNH BÁO TRẠNG THÁI ĐANG HỌC)
            if (_selectedScope == "ALL") 
              Container(
                padding: const EdgeInsets.all(15), 
                decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.blue.shade100)),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, color: Colors.blue),
                    const SizedBox(width: 12),
                    const Expanded(child: Text("Hệ thống sẽ gửi tin đến TẤT CẢ sinh viên có trạng thái ĐANG HỌC trong toàn trường.", style: TextStyle(color: Colors.blue, fontSize: 12, fontWeight: FontWeight.w500))),
                  ],
                ),
              ),

            // ... (Phần LHP_LOW giữ nguyên như bản trước) ...
            if (_selectedScope == "LHP_LOW") ...[
               // Code lọc lớp sĩ số thấp và xem danh sách SV (Giữ nguyên bản trước của Sơn)
               _buildLowEnrollmentUI(),
            ],

            const Divider(height: 50),
            NotificationHelper.buildLabel("Nội dung thông báo (Rich Text)"),
            NotificationHelper.buildDropdown(hint: "Loại tin", items: _categories.map((e) => e['id']!).toList(), value: _selectedCategory, onChanged: (v) => setState(() => _selectedCategory = v!), displayFunc: (id) => _categories.firstWhere((e) => e['id'] == id)['name']!),
            const SizedBox(height: 12),
            TextField(controller: _titleController, decoration: NotificationHelper.inputDecor("Tiêu đề", Icons.title)),
            const SizedBox(height: 12),
            TextField(controller: _contentController, maxLines: 4, decoration: NotificationHelper.inputDecor("Nội dung (hỗ trợ dán link tự động)", Icons.message)),
            const SizedBox(height: 12),
            TextField(
              controller: _imageUrlController, 
              decoration: NotificationHelper.inputDecor("Link ảnh minh họa (tùy chọn)", Icons.image_outlined),
              onChanged: (v) => setState(() {}),
            ),
            if (_imageUrlController.text.isNotEmpty) 
               Padding(padding: const EdgeInsets.only(top: 10), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(_imageUrlController.text, height: 120, width: double.infinity, fit: BoxFit.cover, errorBuilder: (c, e, s) => const Text("Link ảnh không hợp lệ", style: TextStyle(color: Colors.red, fontSize: 10))))),

            const SizedBox(height: 30),
            SizedBox(width: double.infinity, height: 55, child: ElevatedButton(onPressed: _isLoading ? null : _handleSend, style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0054A6), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: _isLoading ? const CircularProgressIndicator(color: Colors.white) : const Text("XÁC NHẬN GỬI TIN", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))),
          ],
        ),
      ),
    );
  }

  // Hàm phụ trợ để giao diện gọn hơn
  Widget _buildLowEnrollmentUI() {
    return Column(children: [
       Row(children: [
          Expanded(child: TextField(controller: _thresholdController, keyboardType: TextInputType.number, decoration: NotificationHelper.inputDecor("Sĩ số < X", Icons.person_search))),
          const SizedBox(width: 10),
          ElevatedButton(onPressed: _isSearching ? null : _searchLowEnrollmentData, style: ElevatedButton.styleFrom(backgroundColor: Colors.orange), child: _isSearching ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white)) : const Text("TÌM LỚP")),
       ]),
       const SizedBox(height: 15),
       if (_lowEnrollmentClasses.isNotEmpty) ...[
         // Danh sách lớp sĩ số thấp và Checkbox... (Sơn giữ code cũ ở đây)
       ]
    ]);
  }
}