import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'send_individual_screen.dart';
import 'send_group_screen.dart';
import 'notification_history_screen.dart';

class NotificationPortalScreen extends StatefulWidget {
  const NotificationPortalScreen({super.key});

  @override
  State<NotificationPortalScreen> createState() => _NotificationPortalScreenState();
}

class _NotificationPortalScreenState extends State<NotificationPortalScreen> {
  String _userRole = "canbo"; // Mặc định

  @override
  void initState() {
    super.initState();
    _checkRole();
  }

  Future<void> _checkRole() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _userRole = (prefs.getString('user_role') ?? "canbo").toLowerCase();
    });
  }

  // Logic kiểm tra xem có phải Quyền cao (Admin/Cố vấn) không
  bool get _hasHighPrivilege => _userRole == 'admin' || _userRole == 'covan' || _userRole == 'ad';

  @override
  Widget build(BuildContext context) {
    const Color vinhUniBlue = Color(0xFF0054A6);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        backgroundColor: vinhUniBlue, elevation: 0, centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20), onPressed: () => Navigator.pop(context)),
        title: const Text("TRUNG TÂM THÔNG BÁO", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Chọn phương thức gửi tin", style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2, crossAxisSpacing: 15, mainAxisSpacing: 15, childAspectRatio: 0.9,
                children: [
                  _buildMenuCard(context, "Gửi cá nhân", "Gửi cho 1 hoặc nhiều SV", Icons.person_add_alt_1, Colors.orange, const SendIndividualScreen()),
                  _buildMenuCard(context, "Gửi nhóm lớp", "Lớp học phần đang dạy", Icons.groups_rounded, Colors.blue, const SendGroupScreen()),
                  
                  // 🔥 CHỈ HIỆN "LỌC ADMIN" CHO ADMIN/COVAN
                  if (_hasHighPrivilege)
                    _buildMenuCard(context, "Lọc Admin", "Khóa học, Lớp HC, Toàn trường", Icons.admin_panel_settings, Colors.red, const SendGroupScreen(initialScope: "LOP_HC")),
                  
                  _buildMenuCard(context, "Lịch sử tin", "Xem thống kê & người đọc", Icons.history_edu_rounded, Colors.teal, const NotificationHistoryScreen()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuCard(BuildContext context, String title, String desc, IconData icon, Color color, Widget target) {
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => target)),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 5))],
          border: Border.all(color: color.withOpacity(0.1)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle), child: Icon(icon, color: color, size: 28)),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 4),
            Text(desc, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}