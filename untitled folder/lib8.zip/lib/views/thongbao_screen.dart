import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'thongbao_chitiet_screen.dart';
import '../services/notification_service.dart';
import '../services/database_helper.dart';

class ThongBaoScreen extends StatefulWidget {
  const ThongBaoScreen({super.key});

  @override
  State<ThongBaoScreen> createState() => _ThongBaoScreenState();
}

class _ThongBaoScreenState extends State<ThongBaoScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final Color vinhUniBlue = const Color(0xFF0054A6);
  
  List<dynamic> generalNotifs = []; // Tab TỪ VINHUNI
  List<dynamic> personalNotifs = []; // Tab CÁ NHÂN
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    fetchNotifications();
  }

  // 🔥 FIX LỖI: Khôi phục hàm fetchNotifications và xóa đoạn SQL dán nhầm
  Future<void> fetchNotifications() async {
    if (!mounted) return;
    setState(() => isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      // Lấy ID sinh viên đã làm sạch (user_code)
      final String? userId = prefs.getString('user_code') ?? prefs.getString('user_id');
      
      if (userId == null) {
        if (mounted) setState(() => isLoading = false);
        return;
      }

      // Gọi service đồng bộ thông báo từ Server và SQLite
      final List<dynamic> data = await NotificationService.fetchAndSyncNotifs(userId);
      
      if (mounted) {
        setState(() {
          // Phân loại: GENERAL (Từ trường) và PERSONAL (Cá nhân)
          generalNotifs = data.where((n) {
            final loai = n['LoaiTin']?.toString().toUpperCase() ?? "";
            return loai != 'PERSONAL';
          }).toList();

          personalNotifs = data.where((n) {
            final loai = n['LoaiTin']?.toString().toUpperCase() ?? "";
            return loai == 'PERSONAL';
          }).toList();

          isLoading = false;
        });
      }
    } catch (e) {
      debugPrint("❌ Lỗi tải thông báo: $e");
      if (mounted) setState(() => isLoading = false);
    }
  }

  // Hàm xử lý xóa vĩnh viễn (Đồng bộ Server + SQLite)
  Future<void> _handleDeleteAction(int id, int index, bool isPersonal) async {
    final prefs = await SharedPreferences.getInstance();
    final String? studentId = prefs.getString('user_code') ?? prefs.getString('user_id');

    // 1. Cập nhật UI ngay lập tức
    setState(() {
      if (isPersonal) {
        personalNotifs.removeAt(index);
      } else {
        generalNotifs.removeAt(index);
      }
    });

    // 2. Xóa trong SQLite Local
    await DatabaseHelper.instance.softDelete(id);

    // 3. Gọi API ẩn phía Server
    if (studentId != null) {
      _syncDeleteToServer(id, studentId);
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Đã xóa thông báo"),
          behavior: SnackBarBehavior.floating,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _syncDeleteToServer(int notifId, String studentId) async {
    try {
      final response = await http.post(
        Uri.parse("https://mobi.vinhuni.edu.vn/api/hide-notif/$notifId"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"student_id": studentId}),
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        debugPrint("✅ Đã đồng bộ ẩn tin $notifId lên Server");
      }
    } catch (e) {
      debugPrint("⚠️ Không thể đồng bộ xóa: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        automaticallyImplyLeading: false, 
        title: const Text("Thông báo", 
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0.5,
        bottom: TabBar(
          controller: _tabController,
          labelColor: vinhUniBlue,
          unselectedLabelColor: Colors.grey,
          indicatorColor: vinhUniBlue,
          indicatorWeight: 3,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold),
          tabs: const [
            Tab(text: "TỪ VINHUNI"), 
            Tab(text: "CÁ NHÂN"),
          ],
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF0054A6)))
          : TabBarView(
              controller: _tabController,
              children: [
                _buildList(generalNotifs, "Không có thông báo từ trường", false),
                _buildList(personalNotifs, "Không có tin nhắn cá nhân", true),
              ],
            ),
    );
  }

  Widget _buildList(List<dynamic> list, String emptyMsg, bool isPersonal) {
    if (list.isEmpty && !isLoading) {
      return Center(child: Text(emptyMsg));
    }
    
    return RefreshIndicator(
      onRefresh: fetchNotifications,
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: list.length,
        itemBuilder: (context, index) {
          final notif = list[index];
          return Dismissible(
            key: Key(notif['ID'].toString()),
            direction: DismissDirection.endToStart,
            background: Container(
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: Colors.red.shade400,
                borderRadius: BorderRadius.circular(16),
              ),
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: const Icon(Icons.delete_sweep, color: Colors.white, size: 28),
            ),
            onDismissed: (direction) {
              _handleDeleteAction(notif['ID'], index, isPersonal);
            },
            child: _buildNotificationCard(notif),
          );
        },
      ),
    );
  }

  Widget _buildNotificationCard(dynamic notif) {
    bool isRead = notif['IsRead'] ?? false;
    bool isGeneral = (notif['LoaiTin'] != 'PERSONAL');

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ChiTietThongBaoScreen(notification: notif),
          ),
        ).then((_) {
          fetchNotifications(); 
          if (NotificationService.onRefreshBadge != null) {
            NotificationService.onRefreshBadge!();
          }
        });
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: isRead ? Colors.white : const Color(0xFFF0F7FF),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isRead ? Colors.transparent : vinhUniBlue.withOpacity(0.1)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 3))],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              backgroundColor: isGeneral ? vinhUniBlue.withOpacity(0.1) : Colors.orange.withOpacity(0.1),
              child: Icon(
                isGeneral ? Icons.school_rounded : Icons.person_rounded,
                color: isGeneral ? vinhUniBlue : Colors.orange,
                size: 20,
              ),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(notif['NgayPhatHanh'] ?? "", style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      if (!isRead) const Icon(Icons.circle, color: Colors.red, size: 8),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(notif['TieuDe'] ?? "", 
                      style: TextStyle(
                        fontWeight: isRead ? FontWeight.w500 : FontWeight.bold, 
                        fontSize: 15, 
                        color: Colors.black87
                      ),
                      maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 6),
                  Text("Người gửi: ${notif['NguoiDang'] ?? 'VinhUni'}", 
                      style: TextStyle(
                        fontSize: 12, 
                        color: Colors.blueGrey.shade600, 
                        fontWeight: FontWeight.w500
                      )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}