import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async'; 
import 'qr_generator_screen.dart'; // 🔥 ĐẢM BẢO ĐÃ CÓ FILE NÀY

class MoDiemDanhScreen extends StatefulWidget {
  final String lecturerId;
  const MoDiemDanhScreen({super.key, required this.lecturerId});

  @override
  State<MoDiemDanhScreen> createState() => _MoDiemDanhScreenState();
}

class _MoDiemDanhScreenState extends State<MoDiemDanhScreen> {
  // --- BIẾN TRẠNG THÁI ---
  String? _selectedLhp;
  String _generatedCode = "";
  bool _isLoading = false;
  bool _isFetching = false;
  List _myClasses = [];
  List _attendanceReport = [];
  int _presentCount = 0;
  
  // 🔥 Biến quản lý thời gian hết hạn (GV điều chỉnh)
  int _selectedDuration = 10; 
  
  Timer? _attendanceTimer;
  final Color vinhUniBlue = const Color(0xFF0054A6);

  @override
  void initState() {
    super.initState();
    _fetchMyClasses();
  }

  @override
  void dispose() {
    _attendanceTimer?.cancel();
    super.dispose();
  }

  // --- 1. LẤY DANH SÁCH LỚP DẠY ---
  Future<void> _fetchMyClasses() async {
    const String nam = "2025-2026"; 
    const String ky = "Học kỳ 1";
    final cleanId = widget.lecturerId.replaceAll("CB", "");
    final url = "https://mobi.vinhuni.edu.vn/api/lecturer/classes-filtered?lecturer_id=$cleanId&nam=$nam&ky=$ky";
    
    try {
      final res = await http.get(Uri.parse(url));
      if (res.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(res.body);
        if (responseData['status'] == 'success') {
          setState(() {
            _myClasses = responseData['data'] ?? []; 
            if (_myClasses.isNotEmpty) {
              _selectedLhp = _myClasses[0]['ma_lop']?.toString();
            }
          });
        }
      }
    } catch (e) {
      debugPrint("❌ Lỗi tải danh sách lớp: $e");
    }
  }

  // --- 2. SINH MÃ & MỞ PHIÊN ---
  Future<void> _generatePin() async {
    if (_selectedLhp == null) {
      _showSnackBar("Vui lòng chọn một lớp học phần!", Colors.orange);
      return;
    }
    
    setState(() => _isLoading = true);
    try {
      final response = await http.post(
        Uri.parse("https://mobi.vinhuni.edu.vn/api/attendance/create-session"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "lhp_code": _selectedLhp,
          "lecturer_id": widget.lecturerId,
          "type": "QR_PIN", // Hỗ trợ cả 2 loại
          "duration": _selectedDuration, // 🔥 Gửi thời gian GV đã chọn
          "lat": 18.659,
          "lon": 105.695,
        }),
      );

      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        String code = data['code']?.toString() ?? "";
        setState(() {
          _generatedCode = code;
        });

        // Tự động hiện lựa chọn QR/PIN sau khi sinh mã thành công
        String tenLop = _myClasses.firstWhere((c) => c['ma_lop'] == _selectedLhp)['ten_lop'] ?? "Lớp học";
        _showAttendanceOption(code, tenLop);

        _attendanceTimer?.cancel();
        _attendanceTimer = Timer.periodic(const Duration(seconds: 5), (t) => _fetchAttendanceData());
        _fetchAttendanceData();
        
      } else {
        _showSnackBar(data['message'] ?? "Không thể sinh mã", Colors.red);
      }
    } catch (e) {
      _showSnackBar("Lỗi kết nối Server", Colors.red);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // --- 3. LẤY DỮ LIỆU ĐIỂM DANH REAL-TIME ---
  Future<void> _fetchAttendanceData() async {
    if (_isFetching || _selectedLhp == null) return;
    _isFetching = true;
    try {
      final url = "https://mobi.vinhuni.edu.vn/api/attendance/session-report/$_selectedLhp";
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 4));
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == 'success' && mounted) {
          setState(() {
            _attendanceReport = data['data'] ?? [];
            _presentCount = data['present_count'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("📡 Lỗi cập nhật danh sách: $e");
    } finally {
      _isFetching = false;
    }
  }

  // 🔥 4. LỰA CHỌN HIỂN THỊ (PIN HOẶC QR)
  void _showAttendanceOption(String generatedPin, String tenLop) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("CA ĐIỂM DANH ĐÃ MỞ!", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 20),
            ListTile(
              leading: const CircleAvatar(backgroundColor: Colors.blue, child: Icon(Icons.numbers, color: Colors.white)),
              title: const Text("Hiển thị mã PIN"),
              subtitle: const Text("Dành cho SV nhập tay"),
              onTap: () => Navigator.pop(context),
            ),
            const Divider(),
            ListTile(
              leading: const CircleAvatar(backgroundColor: Colors.orange, child: Icon(Icons.qr_code_2, color: Colors.white)),
              title: const Text("Hiện mã QR Máy chiếu"),
              subtitle: const Text("Quét nhanh, chính xác hơn"),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => QRGeneratorScreen(attendanceCode: generatedPin, className: tenLop),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text("MỞ PHIÊN ĐIỂM DANH", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        backgroundColor: vinhUniBlue,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("1. Chọn lớp học phần:", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blueGrey)),
            const SizedBox(height: 10),
            _buildDropdown(),
            
            const SizedBox(height: 25),
            const Text("2. Thời gian hiệu lực (phút):", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blueGrey)),
            const SizedBox(height: 10),
            _buildTimerSelection(),

            const SizedBox(height: 30),
            _buildGenerateButton(),

            if (_generatedCode.isNotEmpty) ...[
              const SizedBox(height: 40),
              _buildPinDisplay(),
              const Divider(height: 60),
              _buildAttendanceList(),
            ]
          ],
        ),
      ),
    );
  }

  // --- CÁC WIDGET BỔ TRỢ ---

  Widget _buildDropdown() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade300)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          isExpanded: true,
          value: _selectedLhp,
          items: _myClasses.map((c) => DropdownMenuItem<String>(
            value: c['ma_lop']?.toString(), 
            child: Text(c['ten_lop']?.toString() ?? "Lớp", style: const TextStyle(fontSize: 13))
          )).toList(),
          onChanged: (v) => setState(() => _selectedLhp = v),
        ),
      ),
    );
  }

  Widget _buildTimerSelection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [5, 10, 15, 30].map((m) => ChoiceChip(
        label: Text("$m phút"),
        selected: _selectedDuration == m,
        onSelected: (val) => setState(() => _selectedDuration = m),
        selectedColor: vinhUniBlue.withOpacity(0.2),
        labelStyle: TextStyle(color: _selectedDuration == m ? vinhUniBlue : Colors.black, fontWeight: FontWeight.bold),
      )).toList(),
    );
  }

  Widget _buildGenerateButton() {
    return SizedBox(
      width: double.infinity, height: 50,
      child: ElevatedButton.icon(
        onPressed: _isLoading ? null : _generatePin,
        icon: _isLoading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white)) : const Icon(Icons.bolt, color: Colors.white),
        label: const Text("MỞ ĐIỂM DANH", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade800, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
      ),
    );
  }

  Widget _buildPinDisplay() {
    return Center(
      child: Column(
        children: [
          const Text("MÃ ĐANG HIỆU LỰC:", style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 10),
          GestureDetector(
            onTap: () => _showAttendanceOption(_generatedCode, "Lớp của Sơn"),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(25), border: Border.all(color: Colors.blue.shade200, width: 2)),
              child: Text(_generatedCode, style: TextStyle(fontSize: 55, fontWeight: FontWeight.bold, letterSpacing: 10, color: vinhUniBlue)),
            ),
          ),
          const SizedBox(height: 10),
          Text("Hết hạn sau $_selectedDuration phút", style: const TextStyle(color: Colors.red, fontSize: 12, fontStyle: FontStyle.italic)),
        ],
      ),
    );
  }

  Widget _buildAttendanceList() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("SINH VIÊN ĐÃ QUÉT ($_presentCount)", style: const TextStyle(fontWeight: FontWeight.bold)),
            IconButton(icon: const Icon(Icons.qr_code), onPressed: () => _showAttendanceOption(_generatedCode, "Lớp của Sơn")),
          ],
        ),
        ListView.builder(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          itemCount: _attendanceReport.length,
          itemBuilder: (ctx, idx) {
            final sv = _attendanceReport[idx];
            bool isPresent = sv['is_present'] ?? false;
            return ListTile(
              leading: CircleAvatar(backgroundImage: NetworkImage("https://mobi.vinhuni.edu.vn/api/get-avatar/${sv['sid']}")),
              title: Text(sv['name'] ?? "Sinh viên", style: TextStyle(color: isPresent ? Colors.black : Colors.grey)),
              trailing: Icon(isPresent ? Icons.check_circle : Icons.radio_button_unchecked, color: isPresent ? Colors.green : Colors.grey),
            );
          },
        ),
      ],
    );
  }

  void _showSnackBar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color, behavior: SnackBarBehavior.floating));
  }
}