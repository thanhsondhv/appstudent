import 'dart:convert';
import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import 'database_helper.dart';

// Import màn hình chi tiết và key điều hướng toàn cục
import '../main.dart'; 
import '../views/thongbao_chitiet_screen.dart';

class NotificationService {
  static const String domainApi = "https://mobi.vinhuni.edu.vn/api";
  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();
  static Function? onRefreshBadge;

  // --- HÀM KHỞI TẠO DỊCH VỤ ---
  Future<void> initialize() async {
    // 1. Kiểm tra xem có phải Simulator iOS không
    if (Platform.isIOS) {
      final deviceInfo = DeviceInfoPlugin();
      final iosInfo = await deviceInfo.iosInfo;
      if (!iosInfo.isPhysicalDevice) {
        debugPrint("⚠️ iOS Simulator detected: Bỏ qua Firebase Messaging.");
        return;
      }
    }

    FirebaseMessaging messaging = FirebaseMessaging.instance;

    // Cấu hình hiển thị thông báo cho Android
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    // Cấu hình hiển thị thông báo cho iOS
    const DarwinInitializationSettings initializationSettingsDarwin =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsDarwin,
    );

    // Khởi tạo và xử lý sự kiện nhấn vào thông báo Local (Khi app đang mở)
    await _localNotifications.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        if (response.payload != null) {
          final Map<String, dynamic> data = jsonDecode(response.payload!);
          _handleNavigation(data);
        }
      },
    );

    try {
      // Yêu cầu quyền thông báo
      await messaging.requestPermission(alert: true, badge: true, sound: true);

      if (Platform.isIOS) {
        await messaging.setForegroundNotificationPresentationOptions(
            alert: true, badge: true, sound: true);
      }

      // A. Lắng nghe thông báo khi App đang mở (Foreground)
      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        _showLocalNotification(message);
        updateBadgeCount(); // Cập nhật số badge ngay khi tin nhắn tới
      });

      // B. Lắng nghe khi nhấn vào thông báo (App đang chạy nền - Background)
      FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
        debugPrint("🚀 Nhấn vào thông báo khi App đang chạy nền");
        _handleNavigation(message.data);
      });

      // C. Lắng nghe khi App bị tắt hoàn toàn (Terminated) và được mở từ thông báo
      FirebaseMessaging.instance.getInitialMessage().then((RemoteMessage? message) {
        if (message != null) {
          debugPrint("🚀 App mở từ trạng thái tắt bởi thông báo");
          Future.delayed(const Duration(seconds: 1), () {
            _handleNavigation(message.data);
          });
        }
      });

      // D. Cập nhật Badge ngay khi khởi tạo xong
      updateBadgeCount();

    } catch (e) {
      debugPrint("⚠️ Lỗi khởi tạo Firebase: $e");
    }
  }

  // --- HÀM ĐỒNG BỘ DỮ LIỆU OFFLINE (SQLITE) ---
  static Future<List<dynamic>> fetchAndSyncNotifs(String userId) async {
    // 1. Lấy tin nhắn cũ trong máy hiện lên ngay (Cực nhanh)
    List<dynamic> localData = await DatabaseHelper.instance.getOfflineNotifs();

    try {
      // 2. Tải tin mới từ Server (Tăng timeout lên 15s để tránh lỗi mạng chậm)
      final response = await http.get(
        Uri.parse("$domainApi/get-notifs/$userId?page=1")
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final List<dynamic> serverData = json.decode(utf8.decode(response.bodyBytes));
        
        // 3. Lưu vào máy. Vòng lặp này sẽ ghi đè tin cũ nhờ ConflictAlgorithm.replace
        for (var n in serverData) {
          await DatabaseHelper.instance.insertNotification(n);
        }
        
        // 4. Lấy lại dữ liệu sạch nhất từ SQLite để trả về
        return await DatabaseHelper.instance.getOfflineNotifs();
      }
    } catch (e) {
      debugPrint("🔥 Lỗi đồng bộ (sẽ dùng offline): $e");
    }
    
    return localData;
  }

  // --- HÀM CẬP NHẬT SỐ LƯỢNG THÔNG BÁO CHƯA ĐỌC (BADGE) ---
  Future<void> updateBadgeCount() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? userId = prefs.getString('user_id') ?? prefs.getString('user_code'); 
      
      if (userId == null || userId.isEmpty) return;

      final response = await http.get(
        Uri.parse("$domainApi/count-unread/$userId")
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        int unreadCount = data['unread_count'] ?? 0;

        bool isSupported = await FlutterAppBadger.isAppBadgeSupported();
        if (isSupported) {
          if (unreadCount > 0) {
            FlutterAppBadger.updateBadgeCount(unreadCount);
          } else {
            FlutterAppBadger.removeBadge();
          }
        }
        
        debugPrint("🔔 Số thông báo chưa đọc đã cập nhật: $unreadCount");
        await prefs.setInt('unread_notif_count', unreadCount);

        // Gọi callback làm mới giao diện nếu có
        if (onRefreshBadge != null) onRefreshBadge!();
      }
    } catch (e) {
      debugPrint("⚠️ Lỗi updateBadgeCount: $e");
    }
  }

  // --- HÀM XỬ LÝ ĐIỀU HƯỚNG CHI TIẾT ---
  static Future<void> _handleNavigation(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    final bool isLoggedIn = prefs.getBool('is_logged_in') ?? false;

    if (!isLoggedIn) {
      navigatorKey.currentState?.pushNamedAndRemoveUntil('/', (route) => false);
      return;
    }

    if (data.containsKey('notif_id')) {
      final String notifId = data['notif_id'].toString();

      navigatorKey.currentState?.push(
        MaterialPageRoute(
          builder: (context) => ChiTietThongBaoScreen(
            notification: {
              'ID': int.parse(notifId),
              'TieuDe': 'Đang tải nội dung...', 
              'NoiDung': '',
              'LoaiTin': data['type'] ?? 'PERSONAL'
            },
          ),
        ),
      );
    }
  }

  // --- HIỂN THỊ THÔNG BÁO LOCAL ---
  void _showLocalNotification(RemoteMessage message) async {
    RemoteNotification? notification = message.notification;
    if (notification != null) {
      const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
        'vinhuni_channel_id', 'VinhUni Notifications',
        importance: Importance.max, 
        priority: Priority.high,
      );
      const NotificationDetails platformDetails = NotificationDetails(android: androidDetails);
      
      String payloadData = jsonEncode(message.data);

      await _localNotifications.show(
        notification.hashCode, 
        notification.title, 
        notification.body, 
        platformDetails,
        payload: payloadData,
      );
    }
  }

  // --- ĐỒNG BỘ TOKEN FCM LÊN SERVER ---
  Future<void> syncTokenToServer(String studentId) async {
    try {
      if (Platform.isIOS) {
        final deviceInfo = DeviceInfoPlugin();
        final iosInfo = await deviceInfo.iosInfo;
        if (!iosInfo.isPhysicalDevice) return;
      }

      String? currentToken = await FirebaseMessaging.instance.getToken();
      if (currentToken == null) return;
      
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getString('last_fcm_token') == currentToken) return;

      final response = await http.post(
        Uri.parse("$domainApi/save-fcm-token"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "student_id": studentId,
          "token": currentToken,
          "platform": Platform.isAndroid ? "Android" : "iOS",
          "device_name": Platform.isAndroid ? "Android Device" : "iPhone/iPad"
        }),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        await prefs.setString('last_fcm_token', currentToken);
        debugPrint("✅ Token synced: $studentId");
      }
    } catch (e) {
      debugPrint("⚠️ Không thể sync token: $e");
    }
  }
}