import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class GuiThongBaoScreen extends StatefulWidget {
  const GuiThongBaoScreen({super.key});

  @override
  State<GuiThongBaoScreen> createState() => _GuiThongBaoScreenState();
}

class _GuiThongBaoScreenState extends State<GuiThongBaoScreen> {
  // Controller để lấy dữ liệu từ ô nhập
  final _studentIdController = TextEditingController();
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  
  bool _isLoading = false;
  String _senderId = "CanBo"; // Mặc định nếu không lấy được từ cache

  // Màu chủ đạo VinhUni
  final Color vinhUniBlue = const Color(0xFF0054A6);

  @override
  void initState() {
    super.initState();
    _loadSender();
  }

  @override
  void dispose() {
    _studentIdController.dispose();
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  // Lấy thông tin Cán bộ đang đăng nhập để gửi kèm (để sau này lưu Log)
  Future<void> _loadSender() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _senderId = prefs.getString('user_code') ?? "UnknownCB";
    });
  }

  // --- HÀM GỬI THÔNG BÁO ---
  Future<void> _sendNotification() async {
    // 1. Validate dữ liệu đầu vào
    if (_studentIdController.text.trim().isEmpty || 
        _titleController.text.trim().isEmpty || 
        _contentController.text.trim().isEmpty) {
      _showSnack("Vui lòng nhập đầy đủ thông tin!", Colors.orange);
      return;
    }

    // 2. Bắt đầu trạng thái Loading
    setState(() => _isLoading = true);

    try {
      // 3. Gọi API Backend Python
      final response = await http.post(
        Uri.parse('https://mobi.vinhuni.edu.vn/api/admin/send-personal-notification'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "sender_id": _senderId,
          "student_id": _studentIdController.text.trim(),
          "title": _titleController.text.trim(),
          "content": _contentController.text.trim()
        }),
      ).timeout(const Duration(seconds: 15));

      final result = jsonDecode(response.body);

      // 4. Xử lý kết quả trả về
      if (response.statusCode == 200 && result['status'] == 'success') {
        _showSuccessDialog(result['detail'] ?? "Gửi thành công!");
        
        // Xóa nội dung nhập sau khi gửi xong
        _titleController.clear();
        _contentController.clear();
      } else {
        _showSnack("Lỗi: ${result['message']}", Colors.red);
      }
    } catch (e) {
      _showSnack("Lỗi kết nối Server: $e", Colors.red);
    } finally {
      // Tắt trạng thái Loading dù thành công hay thất bại
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // Hiển thị Dialog thành công
  void _showSuccessDialog(String detail) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 28),
            SizedBox(width: 10),
            Text("Thành công"),
          ],
        ),
        content: Text("Thông báo đã được gửi đi.\n\nChi tiết: $detail"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx), 
            child: const Text("Đóng", style: TextStyle(fontWeight: FontWeight.bold))
          )
        ],
      ),
    );
  }

  // Hiển thị thông báo lỗi nhỏ (SnackBar)
  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg), 
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50], // Màu nền nhẹ
      appBar: AppBar(
        title: const Text("Gửi tin nhắn riêng"),
        backgroundColor: vinhUniBlue,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(), // Ẩn bàn phím khi bấm ra ngoài
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildInfoBanner(),
              const SizedBox(height: 25),
              
              _buildLabel("Mã sinh viên nhận"),
              TextField(
                controller: _studentIdController,
                decoration: _inputDecor("Nhập mã SV (VD: 205714...)", Icons.person_search),
              ),
              const SizedBox(height: 15),

              _buildLabel("Tiêu đề thông báo"),
              TextField(
                controller: _titleController,
                decoration: _inputDecor("VD: Nhắc nhở nộp hồ sơ", Icons.title),
              ),
              const SizedBox(height: 15),

              _buildLabel("Nội dung chi tiết"),
              TextField(
                controller: _contentController,
                maxLines: 5, // Cho phép nhập nhiều dòng
                decoration: _inputDecor("Nhập nội dung tin nhắn...", Icons.message_outlined),
              ),
              const SizedBox(height: 30),

              // Nút Gửi
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: _isLoading ? null : _sendNotification,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: vinhUniBlue,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 5,
                  ),
                  icon: _isLoading 
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) 
                    : const Icon(Icons.send, color: Colors.white),
                  label: Text(
                    _isLoading ? "ĐANG GỬI..." : "GỬI NGAY", 
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Widget hiển thị banner hướng dẫn
  Widget _buildInfoBanner() {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.blue.shade50, 
        borderRadius: BorderRadius.circular(12), 
        border: Border.all(color: Colors.blue.shade100)
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline, color: vinhUniBlue),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              "Tin nhắn sẽ được gửi trực tiếp đến ứng dụng của sinh viên qua hệ thống Firebase.", 
              style: TextStyle(color: Colors.blue.shade900, fontSize: 13, height: 1.4)
            )
          ),
        ],
      ),
    );
  }

  // Widget hiển thị nhãn (Label)
  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 4),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.black87)),
    );
  }

  // Cấu hình giao diện ô nhập liệu
  InputDecoration _inputDecor(String hint, IconData icon) {
    return InputDecoration(
      hintText: hint,
      prefixIcon: Icon(icon, color: Colors.grey),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: vinhUniBlue, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
    );
  }
}