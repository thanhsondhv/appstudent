import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ProfileScreen extends StatefulWidget {
  final VoidCallback? onAvatarUpdate;
  const ProfileScreen({super.key, this.onAvatarUpdate});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final Color vinhUniBlue = const Color(0xFF0054A6);
  String studentName = "Sinh viên";
  String studentId = "";
  bool isNotifEnabled = true;
  bool _isUpdatingFace = false;
  
  // 🔥 Biến lưu Trạng thái & Lớp từ bảng StudentProfiles
  String studentStatus = "Đang tải...";
  String studentClass = "Đang tải...";

  int _imageVersion = DateTime.now().millisecondsSinceEpoch;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    
    // 1. Load data cơ bản và CẮT CHỮ "SV"
    String rawId = prefs.getString('user_id') ?? prefs.getString('user_code') ?? "";
    String cleanId = rawId.toUpperCase().replaceFirst(RegExp(r'^SV'), ''); // Cắt chữ SV ở đầu

    setState(() {
      studentName = prefs.getString('full_name') ?? "Sinh viên";
      studentId = cleanId; // Gán ID đã cắt
      isNotifEnabled = prefs.getBool('receive_notifications') ?? true;
    });

    // 2. Gọi API lấy Trạng thái & Lớp
    if (cleanId.isNotEmpty) {
      _fetchStudentExtraInfo(cleanId);
    }
  }

  // 🔥 HÀM GỌI API LẤY LỚP & TRẠNG THÁI
  Future<void> _fetchStudentExtraInfo(String id) async {
    try {
      final response = await http.get(
        Uri.parse("https://mobi.vinhuni.edu.vn/api/student-info/$id"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            studentStatus = data['trang_thai'];
            studentClass = data['lop_hanh_chinh'];
          });
        } else {
          setState(() {
            studentStatus = "Không xác định";
            studentClass = "Chưa xếp lớp";
          });
        }
      }
    } catch (e) {
      setState(() {
        studentStatus = "Lỗi kết nối";
        studentClass = "Lỗi kết nối";
      });
    }
  }

  Future<void> _updateFaceID() async {
    if (studentId.isEmpty) return;
    final picker = ImagePicker();
    final XFile? image = await showModalBottomSheet<XFile>(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.camera_front_rounded),
              title: const Text('Chụp ảnh khuôn mặt (Camera trước)'),
              onTap: () async => Navigator.pop(context, await picker.pickImage(source: ImageSource.camera, preferredCameraDevice: CameraDevice.front)),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Chọn từ thư viện'),
              onTap: () async => Navigator.pop(context, await picker.pickImage(source: ImageSource.gallery)),
            ),
          ],
        ),
      ),
    );

    if (image == null) return;
    setState(() => _isUpdatingFace = true);

    try {
      var request = http.MultipartRequest('POST', Uri.parse("https://mobi.vinhuni.edu.vn/api/update-face-vector"));
      request.fields['student_id'] = studentId;
      request.files.add(await http.MultipartFile.fromPath('photo', image.path));

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        _showMessage("✅ Đã cập nhật Vector khuôn mặt thành công!");
        setState(() => _imageVersion = DateTime.now().millisecondsSinceEpoch);
        widget.onAvatarUpdate?.call();
      } else {
        final res = jsonDecode(response.body);
        _showMessage("⚠️ ${res['message'] ?? 'Lỗi tạo Vector'}");
      }
    } catch (e) {
      _showMessage("❌ Lỗi kết nối server AI");
    } finally {
      if (mounted) setState(() => _isUpdatingFace = false);
    }
  }

  void _showAboutApp() {
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.55,
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
        child: Column(
          children: [
            const SizedBox(height: 12),
            Container(width: 45, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(25),
                child: Column(
                  children: [
                    const Icon(Icons.school_rounded, size: 70, color: Color(0xFF0054A6)),
                    const SizedBox(height: 15),
                    const Text("Vinh Uni Student", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const Text("Phiên bản 1.0.0", style: TextStyle(color: Colors.grey)),
                    const SizedBox(height: 20),
                    const Text("Ứng dụng cung cấp các dịch vụ học tập trực tuyến, tra cứu điểm thi, thời khóa biểu và bảo mật FaceID.", textAlign: TextAlign.center, style: TextStyle(fontSize: 14, height: 1.5, color: Colors.black87)),
                    const SizedBox(height: 25),
                    _buildAboutItem(Icons.security, "Bảo mật dữ liệu FaceID"),
                    _buildAboutItem(Icons.notifications_active, "Thông báo đẩy thời gian thực"),
                    _buildAboutItem(Icons.update, "Cập nhật dữ liệu đồng bộ"),
                    const SizedBox(height: 20), const Divider(),
                    const Text("© 2026 Vinh University", style: TextStyle(color: Colors.grey, fontSize: 12)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAboutItem(IconData icon, String text) {
    return Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [Icon(icon, size: 20, color: vinhUniBlue), const SizedBox(width: 15), Text(text, style: const TextStyle(fontWeight: FontWeight.w500))]));
  }

  void _toggleNotification(bool value) async {
    setState(() => isNotifEnabled = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('receive_notifications', value);

    if (value) {
      await FirebaseMessaging.instance.subscribeToTopic("vinhuni_all_students");
      _showMessage("🔔 Đã BẬT nhận thông báo");
    } else {
      await FirebaseMessaging.instance.unsubscribeFromTopic("vinhuni_all_students");
      _showMessage("🔕 Đã TẮT nhận thông báo");
    }
  }

  void _showChangePasswordDialog() {
    final oldPassCtrl = TextEditingController();
    final newPassCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Đổi mật khẩu"), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: oldPassCtrl, obscureText: true, decoration: const InputDecoration(labelText: "Mật khẩu cũ")),
          const SizedBox(height: 10),
          TextField(controller: newPassCtrl, obscureText: true, decoration: const InputDecoration(labelText: "Mật khẩu mới")),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Hủy")),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: vinhUniBlue, foregroundColor: Colors.white), onPressed: () { Navigator.pop(context); _changePassword(oldPassCtrl.text, newPassCtrl.text); }, child: const Text("Lưu")),
        ],
      ),
    );
  }

  Future<void> _changePassword(String oldPass, String newPass) async {
    try {
      final response = await http.post(Uri.parse("https://mobi.vinhuni.edu.vn/api/change-password"), headers: {"Content-Type": "application/json"}, body: jsonEncode({"student_id": studentId, "old_pass": oldPass, "new_pass": newPass}));
      if (response.statusCode == 200) _showMessage("✅ Đổi mật khẩu thành công!");
      else _showMessage("⚠️ Mật khẩu cũ không chính xác");
    } catch (e) { _showMessage("Lỗi kết nối server"); }
  }

  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
  }

  void _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    final String avatarUrl = "https://mobi.vinhuni.edu.vn/api/get-avatar/$studentId?v=$_imageVersion";
    
    // Màu sắc động dựa vào Trạng thái SV
    Color statusColor = studentStatus.toLowerCase().contains("tốt nghiệp") ? Colors.green 
                      : studentStatus.toLowerCase().contains("bảo lưu") ? Colors.orange 
                      : vinhUniBlue;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text("Tài khoản", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.black87)),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        automaticallyImplyLeading: false, // 🔥 TẮT NÚT BACK TRIỆT ĐỂ, CHỐNG LỖI OUT APP
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Bảng Thông tin User
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 35, backgroundColor: vinhUniBlue.withOpacity(0.1),
                    backgroundImage: studentId.isNotEmpty ? NetworkImage(avatarUrl) : null,
                    onBackgroundImageError: studentId.isNotEmpty ? (_, __) {} : null,
                    child: studentId.isEmpty ? Icon(Icons.person, size: 35, color: vinhUniBlue) : null,
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(studentName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                        const SizedBox(height: 4),
                        Text("MSV: $studentId", style: const TextStyle(color: Colors.grey, fontSize: 14, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 8),
                        
                        // 🔥 HIỂN THỊ BADGE LỚP & TRẠNG THÁI TỪ API
                        Wrap(
                          spacing: 8, runSpacing: 6,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(color: Colors.blueGrey.shade50, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.blueGrey.shade200)),
                              child: Text(studentClass, style: TextStyle(fontSize: 11, color: Colors.blueGrey.shade700, fontWeight: FontWeight.w600)),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(color: statusColor.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: statusColor.withOpacity(0.3))),
                              child: Text(studentStatus.toUpperCase(), style: TextStyle(fontSize: 11, color: statusColor, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 25),
            
            const Align(alignment: Alignment.centerLeft, child: Text("  CÀI ĐẶT", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey, fontSize: 12))),
            const SizedBox(height: 10),
            
            Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
              child: Column(
                children: [
                  SwitchListTile(
                    activeColor: vinhUniBlue, secondary: const Icon(Icons.notifications_active_outlined, color: Colors.orange),
                    title: const Text("Nhận thông báo", style: TextStyle(fontSize: 15)), value: isNotifEnabled, onChanged: _toggleNotification,
                  ),
                  const Divider(height: 1, indent: 50),
                  _buildMenuTile(Icons.lock_outline, "Đổi mật khẩu", Colors.blue, onTap: _showChangePasswordDialog),
                  const Divider(height: 1, indent: 50),
                  _buildMenuTile(
                    Icons.face_retouching_natural_rounded, "Cập nhật Face ID", Colors.purple, 
                    onTap: _isUpdatingFace ? null : _updateFaceID,
                    trailing: _isUpdatingFace ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : null,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),
            
            Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
              child: Column(
                children: [
                  _buildMenuTile(Icons.info_outline, "Giới thiệu ứng dụng", Colors.teal, onTap: _showAboutApp),
                  const Divider(height: 1, indent: 50),
                  _buildMenuTile(Icons.logout, "Đăng xuất", Colors.red, onTap: _logout, showArrow: false),
                ],
              ),
            ),
            const SizedBox(height: 30),
            const Text("Vinh University - Student App", style: TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuTile(IconData icon, String title, Color color, {VoidCallback? onTap, Widget? trailing, bool showArrow = true}) {
    return ListTile(
      leading: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle), child: Icon(icon, color: color, size: 20)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15)),
      trailing: trailing ?? (showArrow ? const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.grey) : null),
      onTap: onTap,
    );
  }
}