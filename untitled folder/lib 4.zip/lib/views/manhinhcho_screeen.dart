import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';

// 🔥 IMPORT Service để khởi tạo tại đây
import '../services/notification_service.dart';

class ManHinhChoScreen extends StatefulWidget {
  const ManHinhChoScreen({super.key});

  @override
  State<ManHinhChoScreen> createState() => _ManHinhChoScreenState();
}

class _ManHinhChoScreenState extends State<ManHinhChoScreen> with TickerProviderStateMixin {
  late AnimationController _logoController;
  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;

  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    // 🔥 ĐÃ FIX LỖI: Sử dụng Curves.easeOutBack (Tên chuẩn trong Flutter)
    _logoScale = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.easeOutBack),
    );

    _logoOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: const Interval(0.0, 0.8, curve: Curves.easeIn)),
    );

    _logoController.forward();
    _handleRouting();
  }

  Future<void> _handleRouting() async {
    try {
      await NotificationService().initialize();
      debugPrint("🔔 Notification Service đã khởi tạo thành công");
    } catch (e) {
      debugPrint("⚠️ Lỗi khởi tạo Notification: $e");
    }

    // Thời gian chờ đủ để thấy Logo mượt mà
    await Future.delayed(const Duration(milliseconds: 2500));

    final prefs = await SharedPreferences.getInstance();
    final String? savedId = prefs.getString('user_code') ?? prefs.getString('user_id');

    if (!mounted) return;

    if (savedId != null && savedId.isNotEmpty) {
      try {
        await FirebaseMessaging.instance.subscribeToTopic("vinhuni_all_students");
      } catch (_) {}
      Navigator.of(context).pushReplacementNamed('/home');
    } else {
      Navigator.of(context).pushReplacementNamed('/');
    }
  }

  @override
  void dispose() {
    _logoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Nền Gradient 3 tầng chuyên nghiệp
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0078D4), 
                  Color(0xFF0054A6), 
                  Color(0xFF003366),
                ],
              ),
            ),
          ),
          
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedBuilder(
                  animation: _logoController,
                  builder: (context, child) {
                    return Opacity(
                      opacity: _logoOpacity.value,
                      child: Transform.scale(
                        scale: _logoScale.value,
                        child: child,
                      ),
                    );
                  },
                  child: Column(
                    children: [
                      // 🔥 PHẦN HIỂN THỊ LOGO TRONG ASSETS
                      Container(
                        width: 160,
                        height: 160,
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.1),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.15),
                              blurRadius: 30,
                              spreadRadius: 5,
                            )
                          ],
                        ),
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/logo.png', // Tên logo của bạn
                            fit: BoxFit.contain,
                            errorBuilder: (context, error, stackTrace) {
                              // Nếu lỗi đường dẫn ảnh, hiện icon school dự phòng
                              return const Icon(Icons.school_rounded, size: 80, color: Colors.white);
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      const Text(
                        "VINH UNIVERSITY",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                          shadows: [
                            Shadow(color: Colors.black26, offset: Offset(0, 4), blurRadius: 10)
                          ]
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "STUDENT ECOSYSTEM",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 13,
                          letterSpacing: 2,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 100),
                // Thanh progress bar tinh tế
                SizedBox(
                  width: 100,
                  child: LinearProgressIndicator(
                    backgroundColor: Colors.white.withOpacity(0.1),
                    color: Colors.white,
                    minHeight: 2,
                  ),
                ),
              ],
            ),
          ),

          // Thông tin bản quyền dưới đáy
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Text(
                  "Version 1.0.0",
                  style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
                ),
                const SizedBox(height: 4),
                Text(
                  "© VIỆN NC&ĐTTT - VINH UNIVERSITY",
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.4),
                    fontSize: 10,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}