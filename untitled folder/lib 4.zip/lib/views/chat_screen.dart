import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/services.dart'; 
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:shared_preferences/shared_preferences.dart';

final GlobalKey<ChatScreenState> chatScreenKey = GlobalKey<ChatScreenState>();

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  ChatScreenState createState() => ChatScreenState();
}

class ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, String>> _messages = [];
  List<String> _suggestions = [];

  int _sessionId = 0;
  bool _isTyping = false;
  String? _currentStudentId;
  bool _isLoadingId = true;
  String? _errorMessage;
  bool _hasConsented = false; 

  @override
  void initState() {
    super.initState();
    _initChatData();
    _checkInitialConsent();
  }

  Future<void> _checkInitialConsent() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _hasConsented = prefs.getBool('ai_consented') ?? false);
  }

  void activateChatTab() { if (!_hasConsented) _checkAIConsent(); }

  Future<void> _initChatData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // 🔥 FIX LỖI 1: Đồng bộ dùng 'user_code' vì file Login đang lưu biến này
      final String? userId = prefs.getString('user_code') ?? prefs.getString('user_id');
      if (userId == null) {
        setState(() { _errorMessage = "Phiên đăng nhập hết hạn, vui lòng đăng nhập lại!"; _isLoadingId = false; });
        return;
      }
      setState(() { _currentStudentId = userId; _isLoadingId = false; });
    } catch (e) { debugPrint("❌ Lỗi: $e"); }
  }

  Future<void> _checkAIConsent() async {
    final prefs = await SharedPreferences.getInstance();
    bool hasConsented = prefs.getBool('ai_consented') ?? false;
    if (!hasConsented && mounted) _showConsentPopup(prefs);
    else { setState(() => _hasConsented = true); if (_messages.isEmpty) _sendHello(); }
  }

  void _showConsentPopup(SharedPreferences prefs) {
    showDialog(context: context, barrierDismissible: false, builder: (dialogContext) => PopScope(canPop: false, child: AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Column(children: [Icon(Icons.auto_awesome, size: 48, color: Color(0xFF0054A6)), SizedBox(height: 12), Text("Kích hoạt Trợ lý AI", style: TextStyle(fontWeight: FontWeight.bold))]),
      content: const Text(
        "Để cung cấp câu trả lời và tư vấn chính xác, nội dung trò chuyện và thông tin học tập (Mã SV, kết quả, ngành) của bạn sẽ được gửi tới dịch vụ AI của bên thứ ba (OpenAI).\n\nDữ liệu chỉ dùng để phản hồi, không dùng để huấn luyện mô hình. Bạn có đồng ý không?", 
        textAlign: TextAlign.center,
        style: TextStyle(height: 1.4),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text("Từ chối", style: TextStyle(color: Colors.grey))),
        ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0054A6), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          onPressed: () async { await prefs.setBool('ai_consented', true); if (mounted) { Navigator.pop(dialogContext); setState(() => _hasConsented = true); _sendHello(); } },
          child: const Text("Tôi Đồng Ý", style: TextStyle(color: Colors.white))),
      ],
    )));
  }

  Future<void> _sendHello() async {
    if (_currentStudentId == null) return;
    final prefs = await SharedPreferences.getInstance();
    String fullName = prefs.getString('full_name') ?? "Sinh viên";
    setState(() => _isTyping = true);

    const String urlV2 = "https://mobi.vinhuni.edu.vn/api/chatbot-v2/chat";
    
    try {
      final response = await http.post(
        Uri.parse(urlV2),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"message": "INITIAL_GREETING", "sessionId": 0, "studentId": _currentStudentId, "fullName": fullName}),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        if (mounted) {
          setState(() {
            _messages.add({"role": "assistant", "content": data['mainReply'] ?? "Xin chào $fullName! Mình là Trợ lý AI V2."});
            _suggestions = List<String>.from(data['suggestions'] ?? []);
            _sessionId = data['sessionId'] ?? 0;
          });
        }
      } else {
        _addDefaultGreeting(fullName);
      }
    } catch (e) {
      _addDefaultGreeting(fullName);
    } finally {
      if (mounted) setState(() => _isTyping = false);
    }
  }

  void _addDefaultGreeting(String name) {
    if (mounted && _messages.isEmpty) setState(() { _messages.add({"role": "assistant", "content": "Xin chào $name! Mình là Trợ lý AI của VinhUni. Rất vui được gặp bạn! 😊"}); });
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty || _currentStudentId == null) return;
    final userMessage = text.trim();
    setState(() { _messages.add({"role": "user", "content": userMessage}); _isTyping = true; _suggestions = []; });
    _controller.clear();
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    try {
      final response = await http.post(Uri.parse("https://mobi.vinhuni.edu.vn/api/chatbot-v2/chat"), headers: {"Content-Type": "application/json"},
        body: jsonEncode({"message": userMessage, "sessionId": _sessionId, "studentId": _currentStudentId}),
      ).timeout(const Duration(seconds: 35));
      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        setState(() {
          _messages.add({"role": "assistant", "content": data['mainReply'] ?? "Mình không nhận được câu trả lời."});
          _suggestions = List<String>.from(data['suggestions'] ?? []);
          _sessionId = data['sessionId'] ?? _sessionId;
        });
      }
    } catch (e) { setState(() { _messages.add({"role": "assistant", "content": "⚠️ Kết nối gián đoạn, bạn vui lòng hỏi lại nhé!"}); });
    } finally { if (mounted) { setState(() => _isTyping = false); WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom()); } }
  }

  void _scrollToBottom() { if (_scrollController.hasClients) _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut); }

  Widget _buildBubble(Map<String, String> msg) {
    bool isUser = msg["role"] == "user";
    return Align(alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () { Clipboard.setData(ClipboardData(text: msg["content"]!)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Đã sao chép tin nhắn"))); },
        child: Container(margin: const EdgeInsets.symmetric(vertical: 6), padding: const EdgeInsets.all(12),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.85),
          decoration: BoxDecoration(color: isUser ? const Color(0xFF0054A6) : Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)]),
          child: MarkdownBody(data: msg["content"]!, selectable: false, styleSheet: MarkdownStyleSheet(p: TextStyle(color: isUser ? Colors.white : const Color(0xFF2D3142), fontSize: 15))),
        ),
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Colors.grey.shade200, width: 0.5))),
      child: Row(children: [
        Expanded(child: Container(padding: const EdgeInsets.symmetric(horizontal: 16), decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(24)),
          child: TextField(controller: _controller, maxLines: 4, minLines: 1, style: const TextStyle(fontSize: 15), decoration: const InputDecoration(hintText: "Nhập câu hỏi...", border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 10)), onSubmitted: (val) => _sendMessage(val)))),
        const SizedBox(width: 8),
        CircleAvatar(radius: 18, backgroundColor: const Color(0xFF0054A6), child: IconButton(icon: const Icon(Icons.send_rounded, color: Colors.white, size: 18), onPressed: () => _sendMessage(_controller.text))),
      ]),
    );
  }

  Widget _buildSuggestionsArea() {
    if (_suggestions.isEmpty) return const SizedBox.shrink();
    return Container(height: 50, padding: const EdgeInsets.symmetric(vertical: 8),
      child: ListView.builder(scrollDirection: Axis.horizontal, itemCount: _suggestions.length, padding: const EdgeInsets.symmetric(horizontal: 10),
        itemBuilder: (ctx, i) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ActionChip(label: Text(_suggestions[i], style: const TextStyle(fontSize: 13, color: Color(0xFF0054A6))), backgroundColor: Colors.blue.shade50, onPressed: () => _sendMessage(_suggestions[i])))),
    );
  }

  Widget _buildEmptyState() {
    return FutureBuilder<SharedPreferences>(future: SharedPreferences.getInstance(), builder: (context, snapshot) {
      String name = snapshot.data?.getString('full_name') ?? "bạn";
      return Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 40), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: const Color(0xFF0054A6).withOpacity(0.1), shape: BoxShape.circle), child: const Icon(Icons.auto_awesome, size: 60, color: Color(0xFF0054A6))),
        const SizedBox(height: 24), Text("Xin chào $name! 👋", style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
        const Text("Mình đang lấy dữ liệu học tập dành riêng cho bạn. Đợi mình một xíu nhé...", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 14)),
        const SizedBox(height: 30), TextButton(onPressed: () => _sendHello(), child: const Text("Bạn sẵn sàng chưa, bắt đầu nhé!", style: TextStyle(color: Color(0xFF0054A6)))),
      ])));
    });
  }

  Widget _buildBody() {
    if (_isLoadingId) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_errorMessage != null) return Scaffold(body: Center(child: Text(_errorMessage!, style: const TextStyle(color: Colors.red))));
    if (!_hasConsented) return _buildConsentRequiredScreen();
    
    bool isKeyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0;
    
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        automaticallyImplyLeading: false, // 🔥 FIX LỖI 2: Ẩn nút Back tự động gây văng app
        title: const Text("Trợ lý Học tập AI", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0054A6),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: GestureDetector(onTap: () => FocusScope.of(context).unfocus(),
        child: Column(children: [
          Expanded(child: _messages.isEmpty && !_isTyping ? _buildEmptyState() : ListView.builder(controller: _scrollController, padding: const EdgeInsets.fromLTRB(15, 15, 15, 10), itemCount: _messages.length, itemBuilder: (context, index) => _buildBubble(_messages[index]))),
          if (_isTyping) const LinearProgressIndicator(minHeight: 2, color: Color(0xFF0054A6)),
          _buildSuggestionsArea(), _buildInputArea(),
          if (!isKeyboardOpen) const SizedBox(height: 56), 
        ]),
      ),
    );
  }

  Widget _buildConsentRequiredScreen() {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false, // 🔥 FIX LỖI 2: Ẩn nút Back tự động gây văng app
        title: const Text("Xác nhận Bảo mật", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0054A6),
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30.0), 
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.auto_awesome, size: 80, color: Color(0xFF0054A6)), 
            const SizedBox(height: 20),
            const Text("Trợ lý AI VinhUni", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), 
            const SizedBox(height: 20),
            const Text(
              "Để cung cấp câu trả lời chính xác, ứng dụng sẽ gửi nội dung trò chuyện và thông tin học tập của bạn (Mã SV, Khung ngành, kết quả) tới dịch vụ AI của bên thứ ba (OpenAI).", 
              textAlign: TextAlign.center, 
              style: TextStyle(color: Colors.black87, fontSize: 15, height: 1.5)
            ),
            const SizedBox(height: 15),
            const Text(
              "Dữ liệu của bạn được bảo mật tuyệt đối, chỉ dùng để phân tích câu hỏi và không sử dụng để huấn luyện mô hình. Vui lòng xác nhận để tiếp tục.", 
              textAlign: TextAlign.center, 
              style: TextStyle(color: Colors.grey, fontSize: 13, height: 1.5)
            ),
            const SizedBox(height: 35), 
            ElevatedButton.icon(
              onPressed: () => _checkAIConsent(), 
              icon: const Icon(Icons.check_circle_outline), 
              label: const Text("Đồng ý và Bắt đầu", style: TextStyle(fontSize: 16)), 
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0054A6), 
                foregroundColor: Colors.white, 
                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15), 
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))
              )
            ),
          ])
        )
      ),
    );
  }

  @override Widget build(BuildContext context) { return _buildBody(); }
}