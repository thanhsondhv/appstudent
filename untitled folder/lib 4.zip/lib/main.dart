import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart'; 
import 'firebase_options.dart'; 

// ==========================================
// 1. IMPORT CÁC MÀN HÌNH CŨ
// ==========================================
import 'views/manhinhcho_screeen.dart'; 
import 'screens/login_screen.dart'; // Lưu ý: Nếu file login của bạn nằm trong thư mục views, hãy sửa lại thành 'views/login_screen.dart'
import 'views/home_screen.dart';
import 'views/thoikhoabieu_screen.dart';
import 'views/thongbao_screen.dart';
import 'views/lichthi_screen.dart';
import 'views/diemthi_screen.dart';
import 'views/chat_screen.dart';

// ==========================================
// 2. IMPORT CÁC MÀN HÌNH MỚI (TỪ SQL)
// ==========================================
import 'views/khung_ct_screen.dart';
import 'views/bang_diem_tong_hop_screen.dart';
import 'views/tai_chinh_screen.dart';
import 'views/bhyt_screen.dart';
import 'views/feature_building_screen.dart';
import 'views/gui_thong_bao_screen.dart';

// 🔥 QUAN TRỌNG: Khai báo Navigator Key toàn cục
// Biến này giúp NotificationService có thể chuyển màn hình ngay cả khi không có context
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// Class này giúp bỏ qua lỗi chứng chỉ SSL (Handshake Exception) khi gọi API
class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback = (X509Certificate cert, String host, int port) => true;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Bỏ qua lỗi SSL trên Android/iOS (Trừ Web)
  if (!kIsWeb) HttpOverrides.global = MyHttpOverrides();

  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    debugPrint("✅ [System] Firebase đã sẵn sàng");
  } catch (e) {
    debugPrint("❌ [System] Lỗi Firebase: $e");
  }

  // ⚠️ LƯU Ý: Không khởi tạo NotificationService ở đây nữa.
  // Việc đó đã được chuyển sang 'manhinhcho_screeen.dart' để đảm bảo App đã load xong UI.

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vinh Uni Student',
      debugShowCheckedModeBanner: false,
      
      // 🔥 QUAN TRỌNG: Gán navigatorKey vào MaterialApp
      navigatorKey: navigatorKey, 
      
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFF0054A6),
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0054A6),
          primary: const Color(0xFF0054A6),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
        ),
      ),
      
      // Màn hình đầu tiên là Màn hình chờ (Splash)
      initialRoute: '/splash',
      
      routes: {
        // --- CÁC ROUTE HỆ THỐNG ---
        '/splash': (context) => const ManHinhChoScreen(),
        '/': (context) => const LogInWidget(), 
        '/home': (context) => const HomeScreen(),
        
        // --- CÁC ROUTE CHỨC NĂNG CŨ ---
        '/thoikhoabieu': (context) => const ThoiKhoaBieuScreen(), 
        '/thongbao': (context) => const ThongBaoScreen(),
        '/lichthi': (context) => const LichThiScreen(),
        '/diemthi': (context) => const DiemThiScreen(),
        '/chatscreen': (context) => const ChatScreen(),

        // --- CÁC ROUTE MỚI THEO SQL (Đã bỏ chữ 'const' để tránh lỗi) ---
        '/khungct': (context) => KhungCTScreen(),
        '/tongket': (context) => BangDiemTongHopScreen(),
        '/taichinh': (context) => TaiChinhScreen(),
        '/bhyt': (context) => BHYTScreen(),
        '/diemrenluyen': (context) => FeatureBuildingScreen(title: "ĐIỂM RÈN LUYỆN"),
        '/hocbong': (context) => FeatureBuildingScreen(title: "KẾT QUẢ HỌC BỔNG"),
        '/canhbaoht': (context) => FeatureBuildingScreen(title: "CẢNH BÁO HỌC TẬP"),
        '/guitin': (context) => GuiThongBaoScreen(),
      },
    );
  }
}